﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


            string bsonpath = @"C:\Users\gbcg9\Downloads\新增資料夾\FModel\Output\Exports\Uwo\Content\NonUFS\cms\";
            string jsonpath = @"D:\Downloads\";
            string outputpath = @"D:\Downloads\zh\";


            // LoadBson(bsonpath, jsonpath);
            DirectoryInfo d = new DirectoryInfo(jsonpath);
            FileInfo[] Files = d.GetFiles("*.json");

            DataTable slota = parseAny(Files.Where(x => x.Name.StartsWith("ShipSlot_s")).Select(x => x.FullName).ToList());
            slota = slota.Rows.Cast<DataRow>().Where(x => x["slottype"].ToString().StartsWith("7")).CopyToDataTable();


            DataTable slot = parseAny(Files.Where(x => x.Name.StartsWith("ShipSlot_s")).Select(x => x.FullName).ToList());
            slot = slot.Rows.Cast<DataRow>().Where(x => x["slottype"].ToString().StartsWith("5")).CopyToDataTable();

            string[] selectedColumns = new[] { "id", "name", "ename", "shipSlotGrade", "image", "sellPrice", "Type1052", "Type1090", "Type109" };
            DataTable dt = new DataView(slot).ToTable(false, selectedColumns);

            slot = parseAny(Files.Where(x => x.Name.StartsWith("ShipSlot_s")).Select(x => x.FullName).ToList());
            slot = slot.Rows.Cast<DataRow>().Where(x => x["slottype"].ToString().StartsWith("9")).CopyToDataTable();

            string[] selectedColumns2 = new[] { "id", "name", "ename", "shipSlotGrade", "image", "sellPrice", "Type9", "Type108", "Type109" };
            DataTable dt2 = new DataView(slot).ToTable(false, selectedColumns2);
            // ExportToExcel(slot, jsonpath + "slots3.xlsx");

            string[] selectedColumns3 = new[] { "id", "name", "ename", "shipSlotGrade", "image", "sellPrice", "Type1024", "Type1039", "Type1086", "Type9" };
            slot = parseAny(Files.Where(x => x.Name.StartsWith("ShipSlot_s")).Select(x => x.FullName).ToList());
            slot = slot.Rows.Cast<DataRow>().Where(x => x["slottype"].ToString().StartsWith("8")).CopyToDataTable();
            DataTable dt3 = new DataView(slot).ToTable(false, selectedColumns3);



            //slot = parseAny(Files.Where(x => x.Name.StartsWith("ShipyardShop_s0")).Select(x => x.FullName).ToList());
            //slot = slot.Rows.Cast<DataRow>().Where(x => x["shipSlotId"].ToString().StartsWith("701013")).CopyToDataTable();
            //DataTable dt4 = new DataView(slot).ToTable(false, selectedColumns3);
           

            DataTable chara = parseAny(Files.Where(x => x.Name.StartsWith("Character_s")).Select(x => x.FullName).ToList());
          //  chara = chara.Rows.Cast<DataRow>().Where(x => x["familyName"].ToString().StartsWith("보르자")).CopyToDataTable();
            chara = chara.Rows.Cast<DataRow>().Where(x => x["jobId"].ToString().StartsWith("21401006")).CopyToDataTable();

            //21401006
            DataTable gp = parseAny(Files.Where(x => x.Name.StartsWith("MateRecruitingGroup_s")).Select(x => x.FullName).ToList());
          //  MateRecruitingGroup_s2.

            DataTable mate = parseAny(Files.Where(x => x.Name.StartsWith("Mate_s")).Select(x => x.FullName).ToList());
            //    mate = mate.Rows.Cast<DataRow>().Where(x => x["slottype"].ToString().StartsWith("8")).CopyToDataTable();
         
            dataGridView1.DataSource = dt3;
        }
        public static System.Data.DataTable JoinTwoTables(System.Data.DataTable innerTable, System.Data.DataTable outerTable)
        {
            System.Data.DataTable resultTable = new System.Data.DataTable();
            var innerTableColumns = new List<string>();
            foreach (DataColumn column in innerTable.Columns)
            {
                innerTableColumns.Add(column.ColumnName);
                resultTable.Columns.Add(column.ColumnName);
            }

            var outerTableColumns = new List<string>();
            foreach (DataColumn column in outerTable.Columns)
            {
                if (!innerTableColumns.Contains(column.ColumnName))
                {
                    outerTableColumns.Add(column.ColumnName);
                    resultTable.Columns.Add(column.ColumnName);
                }
            }

            for (int i = 0; i < innerTable.Rows.Count; i++)
            {
                var row = resultTable.NewRow();
                innerTableColumns.ForEach(x =>
                {
                    row[x] = innerTable.Rows[i][x];
                });
                outerTableColumns.ForEach(x =>
                {
                    row[x] = outerTable.Rows[i][x];
                });
                resultTable.Rows.Add(row);
            }
            return resultTable;
        }
        private static System.Data.DataTable parseAny(List<string> files, bool ischara = false)
        {
            string path = "";
            string name = "";

            System.Data.DataTable result = new System.Data.DataTable();
            Dictionary<string, object> dct = parseDic();
            Dictionary<string, object> dcte = parseDicE();
            for (int i = 0; i < files.Count; i++)
            {
                dynamic dic;
                JavaScriptSerializer ser = new JavaScriptSerializer();

                dic = ser.Deserialize<dynamic>(File.ReadAllText(files[i]));


                foreach (KeyValuePair<string, object> item in dic as Dictionary<string, object>)
                {
                    DataRow dr = result.NewRow();
                    foreach (KeyValuePair<string, object> itemo in item.Value as Dictionary<string, object>)
                    {

                        if (!result.Columns.Contains(itemo.Key))
                            result.Columns.Add(itemo.Key);

                        if (!ischara)
                        {
                            if (new string[] { "desc", "name", "firstName","familyName","middleName","particle" }.Contains(itemo.Key) && !result.Columns.Contains("c" + itemo.Key))
                                result.Columns.Add("c" + itemo.Key);

                            if (new string[] { "desc", "name", "firstName", "familyName", "middleName", "particle" }.Contains(itemo.Key) && !result.Columns.Contains("e" + itemo.Key))
                                result.Columns.Add("e" + itemo.Key);

                            if (dct.ContainsKey(itemo.Value.ToString()))
                            {
                                dr[itemo.Key] = itemo.Value;
                                dr["c" + itemo.Key] = dct[itemo.Value.ToString()];
                                dr["e" + itemo.Key] = dcte[itemo.Value.ToString()];
                            }
                            else if (itemo.Key == "desc")
                            {
                                //  dr["c" + itemo.Key] = TranslateText(itemo.Value.ToString());
                                dr[itemo.Key] = itemo.Value;
                            }
                            else if (itemo.Key == "name")
                            {
                                //   dr["c" + itemo.Key] = TranslateText(itemo.Value.ToString());
                                dr[itemo.Key] = itemo.Value;
                            }
                            else
                            {
                                dr[itemo.Key] = itemo.Value;
                            }
                        }

                        if (itemo.Value.GetType() == typeof(object[]))
                        {
                            foreach (Object ob in itemo.Value as Object[])
                            {
                                var aab = ob.GetType();

                                if (ob.GetType() == "1".GetType() || ob.GetType() == 1.GetType())
                                    continue;

                                    var aa = (Dictionary<string, object>)ob;
                                    string column = "";
                                    if (itemo.Key == "stat")
                                    {
                                        column = "Type" + aa["Type"].ToString();
                                        if (!result.Columns.Contains(column))
                                        {

                                            result.Columns.Add(column);
                                        }
                                        //if(aa.ContainsKey("Val"))
                                        if (aa["Type"].ToString() != "0")
                                            dr[column] = aa["Val"].ToString();
                                    }
                                    else if (itemo.Key.Contains("special"))
                                    {
                                        dr[itemo.Key] = String.Join(",", aa.Values.ToArray());
                                    }
                                    else
                                    {

                                        dr[itemo.Key] = String.Join(",", aa.Values.ToArray());
                                    }
                              
                              
                            }
                        }


                    }
                    result.Rows.Add(dr);
                }

            }
            return result;
        }
        private static Dictionary<string, object> parseDic()
        {


            JavaScriptSerializer ser = new JavaScriptSerializer();
            dynamic dic = ser.Deserialize<dynamic>(File.ReadAllText(@"D:\Downloads\loc.txt"));

            var result = (Dictionary<string, object>)((Dictionary<string, object>)dic)[""];


            return result;
        }
        private static Dictionary<string, object> parseDicE()
        {


            JavaScriptSerializer ser = new JavaScriptSerializer();
            ser.MaxJsonLength = int.MaxValue;
            dynamic dic = ser.Deserialize<dynamic>(File.ReadAllText(@"D:\Downloads\loc2.txt"));

            var result = (Dictionary<string, object>)((Dictionary<string, object>)dic)[""];


            return result;
        }
    }
}
